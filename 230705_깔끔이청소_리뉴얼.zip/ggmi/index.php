<?php
if (!defined('_INDEX_')) define('_INDEX_', true);
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/index.php');
    return;
}

if(G5_COMMUNITY_USE === false) {
    include_once(G5_THEME_SHOP_PATH.'/index.php');
    return;
}

include_once(G5_THEME_PATH.'/head.php');
?>

<main>

            <section class="main_visual">
                <h2 class="blind">금맥청소 주요 서비스</h2>
                <div class="slide_wrap">
                    <div class="main_slide">
                        <div class="itm">
                            <h3>아파트입주청소</h3>
                            <p>
                                <strong>신축 아파트나 빌라 등 입주 전 상태</strong>에서의 실내 청소를 말하며
                                보양지 제거, 공사먼지 제거, 오염 제거, 시멘트가루 제거 등
                                구석구석 세밀하게 청소하는 서비스로 가족의 건강을 위해서 입주 전에 꼭 해야 하는 서비스입니다.
                            </p>
                        </div>
                        <div class="itm">
                            <h3>이사 상가 청소</h3>
                            <p>
                                <strong>신축 아파트나 빌라 등 입주 전 상태에서의 실내 청소</strong>를 말하며
                                보양지 제거, 공사먼지 제거, 오염 제거, 시멘트가루 제거 등
                                구석구석 세밀하게 청소다.
                            </p>
                        </div>
                        <div class="itm">
                            <h3>사무실 청소</h3>
                            <p>
                                <strong>상태에서의 실내 청소</strong>를 말하며
                                보양지 제거, 공사먼지 제거, 오염 제거, 시멘트가루 제거 등
                                구석구석 세밀하게 청소하는 서비스로 가족의 건강을 위해서 입주 전에 꼭 해야 하는 서비스입니다.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="main_slogan">
                    <img src="<?=G5_THEME_URL;?>/images/slogan.png" alt="똑 소리나게 잡니다.">
                </div>
            </section>
            <section class="main_content sec">
                <h2 class="blind">금맥청소 주요 서비스 상세</h2>
                <div class="inner content">
                    <figure>
                        <a href="">
                            <div class="img_box">
                                <img src="<?=G5_THEME_URL;?>/images/main_s011.jpg" alt="부산 아파트입주청소">
                            </div>
                            <h3> 부산 아파트입주청소</h3>
                            <p>
                                신축 아파트나 빌라 등 입주 전 상태에서의 실내 청소를 말하며<br />
                                보양지 제거, 공사먼지 제거, 오염 제거, 시멘트가루 제거 등<br />
                                구석구석 세밀하게 청소하는 서비스로 가족의 건강을 위해서 입주 전에 꼭 해야 하는 서비스입니다.
                            </p>
                        </a>
                    </figure>
                    <figure>
                        <a href="">
                            <div class="img_box">
                                <img src="<?=G5_THEME_URL;?>/images/main_s012.jpg" alt="부산 아파트입주청소">
                            </div>
                            <h3>부산 아파트입주청소</h3>
                            <p>
                                신축 아파트나 빌라 등 입주 전 상태에서의 실내 청소를 말하며<br />
                                보양지 제거, 공사먼지 제거, 오염 제거, 시멘트가루 제거 등<br />
                                구석구석 세밀하게 청소하는 서비스로 가족의 건강을 위해서 입주 전에 꼭 해야 하는 서비스입니다.
                            </p>
                        </a>
                    </figure>
                    <figure>
                        <a href="">
                            <div class="img_box">
                                <img src="<?=G5_THEME_URL;?>/images/main_s013.jpg" alt="부산 아파트입주청소">
                            </div>
                            <h3>부산 아파트입주청소</h3>
                            <p>
                                신축 아파트나 빌라 등 입주 전 상태에서의 실내 청소를 말하며<br />
                                보양지 제거, 공사먼지 제거, 오염 제거, 시멘트가루 제거 등<br />
                                구석구석 세밀하게 청소하는 서비스로 가족의 건강을 위해서 입주 전에 꼭 해야 하는 서비스입니다.
                            </p>
                        </a>
                    </figure>
                </div>
            </section>
</main>

<?php
include_once(G5_THEME_PATH.'/tail.php');