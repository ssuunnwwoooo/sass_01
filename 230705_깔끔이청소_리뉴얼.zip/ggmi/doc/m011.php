<?php
$page_title = '회사소개';
$cate_title = '회사소개';
$page_num = 1;
$cate_num = 1;
include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>

<?=$page_title;?>

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>
