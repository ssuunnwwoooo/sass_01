<?php
$page_title = '아파트 청소';
$cate_title = '제품소개';
$page_num = 1;
$cate_num = 2;
include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>

<?=$page_title;?>

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>
