<?
$cate_title = '회사소개';
$page_title = '인사말';
$cate_num = 1;
$page_num = 1;

include '../../../common.php';
include_once(G5_THEME_PATH.'/head.php');
?>

<div class="content">
    <h3><?=$page_title;?></h3>
        <p>
             Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque nesciunt iste animi dolore cum ducimus
             similique dolorum, quaerat sequi voluptatibus?
        </p>
</div>

<?
include_once(G5_THEME_PATH.'/tail.php');
?>
