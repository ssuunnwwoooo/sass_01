<ul class="submenu">
    <li><a href="<?=G5_THEME_URL?>/doc/m021.php">제품소개</a></li>
    <li><a href="">서브메뉴02</a></li>
    <li><a href="">서브메뉴03</a></li>
</ul>