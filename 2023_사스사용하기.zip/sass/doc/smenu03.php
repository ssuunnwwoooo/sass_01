<ul class="submenu">
    <li><a href="/bbs/board.php?bo_table=notice">공지사항</a></li>
    <li><a href="/bbs/board.php?bo_table=qa">문의사항</a></li>
</ul>